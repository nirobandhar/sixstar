
<!DOCTYPE html>
<html>
<head>
<title> </title>
<meta charset='utf-8'>
    <link href="<?php echo base_url()?>css/prints.css" rel="stylesheet" />
    <link href="<?php echo base_url()?>assets/css/custom-styles.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/print.css">
</head>
<style type="text/css" media="print">
.hide{display:none}

</style>
<script type="text/javascript">
function printpage() {
document.getElementById('printButton').style.visibility="hidden";
window.print();
document.getElementById('printButton').style.visibility="visible";  
}
</script>
<body style="background:none;">
<input name="print" type="button" value="Print" id="printButton" onClick="printpage()">

      <table width="800px" >
        <tr>
          <td>
            <!-- <img src="<?php echo base_url();?>assets/img/logo.png" alt="Logo" style="margin-bottom:-50px"> -->
            <div class="headline">
            <div style="text-align:center" >
             <strong style="font-size:18px">M/S. KHAN TRADING COMPANY</strong><br>
             Chastia Electric Market, Shop no.13/A, 134/1 Nawabpur Road, Dhaka-1100<br>
             Phone: 7117527, 7173284 Mobile: 01711-708533, 01711-150254<br>
          
              </div>
          </div>
          </td>
        </tr>
        <tr>
          <td style="float:right">
            <table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="250px" style="text-align:right;"><strong></td>
              </tr>
          </table>
          </td>
        </tr>
        <tr>
            <td colspan="2"><hr><hr></td>
            <td colspan="2"><br></td>
        </tr>
        <tr>
            <td colspan="2" style="background:#ddd;" align="center"><h2 >Purchase Return List</h2></td>
        </tr>
        <tr>
            <td>
            <!-- Page Body -->
          
              <table class="border" cellspacing="0" cellpadding="0" width="100%">
                <tr >
                  <th>Invoice No.</th>
                  <th>Date</th>
                  <th>Supplier Code</th>
                  <th>Supplier Name</th>
                  <th>Return Qty</th>
                  <th>Return Amount</th>
                  <th>Notes</th>
                </tr>
               <?php $total = "";
                    $sql = mysql_query("SELECT tbl_purchasereturn.*,tbl_purchasemaster.*,tbl_supplier.* FROM tbl_purchasereturn left join tbl_purchasemaster on tbl_purchasemaster.PurchaseMaster_InvoiceNo=tbl_purchasereturn.PurchaseMaster_InvoiceNo left join tbl_supplier on tbl_supplier.Supplier_SlNo = tbl_purchasemaster.Supplier_SlNo");
                    while($record = mysql_fetch_array($sql)){
                        $total = $total+$record['PurchaseReturn_ReturnAmount'];
                    ?>
                <tr>
                    <td><?php echo $record['PurchaseMaster_InvoiceNo'] ?></td>
                    <td><?php echo $record['PurchaseReturn_ReturnDate'] ?></td>
                    <td><?php echo $record['Supplier_Code'] ?></td>
                    <td><?php echo $record['Supplier_Name'] ?></td>
                    <td><?php echo $record['PurchaseReturn_ReturnQuantity'] ?></td>
                    <td><?php echo $record['PurchaseReturn_ReturnAmount'] ?></td>
                    <td><?php echo $record['PurchaseReturn_Description'] ?></td>
                </tr>
                <?php } ?>
                <tr>
                    <td colspan="5" align="right"><strong>Total </strong></td>
                    <td><strong><?php echo $total; ?></strong></td>
                    <td></td>
                </tr>
              </table>
            </td>
            
            <!-- Page Body end -->
       
    </table></td>
  </tr>
  
</table>

<div class="provied">
  
  <span style="float:left;font-size:11px;">
<i>"THANK YOU FOR YOUR BUSINESS"</i><br>
  Software Provied By Link-Up Technology</span>
</div>
<div class="signature">
<span style="border-top:1px solid #000;">
  Authorize Signature
</span>
</div>
</body>
</html>

