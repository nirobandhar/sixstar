
<!DOCTYPE html>
<html>
<head>
<title> </title>
<meta charset='utf-8'>
    <link href="<?php echo base_url()?>css/prints.css" rel="stylesheet" />
    <link href="<?php echo base_url()?>assets/css/custom-styles.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/print.css">
</head>
<style type="text/css" media="print">
.hide{display:none}

</style>
<script type="text/javascript">
function printpage() {
document.getElementById('printButton').style.visibility="hidden";
window.print();
document.getElementById('printButton').style.visibility="visible";  
}
</script>
<body style="background:none;">
<input name="print" type="button" value="Print" id="printButton" onClick="printpage()">

      <table width="800px" >
        <tr>
          <td>
            <!-- <img src="<?php echo base_url();?>assets/img/logo.png" alt="Logo" style="margin-bottom:-50px"> -->
            <div class="headline">
            <div style="text-align:center" >
             <strong style="font-size:18px">M/S. KHAN TRADING COMPANY</strong><br>
             Chastia Electric Market, Shop no.13/A, 134/1 Nawabpur Road, Dhaka-1100<br>
             Phone: 7117527, 7173284 Mobile: 01711-708533, 01711-150254<br>
          
              </div>
          </div>
          </td>
        </tr>
        <tr>
          <td style="float:right">
            <table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="250px" style="text-align:right;"><strong></td>
              </tr>
          </table>
          </td>
        </tr>
        <tr>
            <td colspan="2"><hr><hr></td>
            <td colspan="2"><br></td>
        </tr>
        <tr>
            <td colspan="2" style="background:#ddd;" align="center"><h2 >Current Stock</h2></td>
        </tr>
        <tr>
            <td>
            <!-- Page Body -->
          
              <table class="border" cellspacing="0" cellpadding="0" width="100%">
                <tr>
                  <th>Product Name</th>
                  <th>Qty</th>
                  <th>Purchase Price</th>
                  <th>Total Price</th>
                  <th>Unit</th>
                </tr>
              <?php $totalqty = "";$sellTOTALqty = ""; $subtotal = "";
        $sql = mysql_query("SELECT tbl_purchaseinventory.*,tbl_product.*,tbl_purchasedetails.* FROM tbl_purchaseinventory left join tbl_product on tbl_product.Product_SlNo = tbl_purchaseinventory.purchProduct_IDNo left join tbl_purchasedetails on tbl_purchasedetails.Product_IDNo = tbl_product.Product_SlNo group by tbl_purchasedetails.Product_IDNo");
        while($record = mysql_fetch_array($sql)){
            
                $totalqty = $record['PurchaseInventory_TotalQuantity'] -$record['PurchaseInventory_ReturnQuantity'];
                $totalqty = $totalqty-$record['PurchaseInventory_DamageQuantity'];
                
                $PID = $record['purchProduct_IDNo'];
                // Sell qty
                $sqq = mysql_query("SELECT * FROM tbl_saleinventory WHERE sellProduct_IdNo = '$PID'");
                $or = mysql_fetch_array($sqq);
                if($or['SaleInventory_packname'] ==""){
                $sellTOTALqty = $or['SaleInventory_TotalQuantity'];
               
                $sellTOTALqty = $sellTOTALqty-$or['SaleInventory_DamageQuantity'];
                $totalqty = $totalqty -$sellTOTALqty+$or['SaleInventory_ReturnQuantity'];
                if($totalqty !="0"){
                    $rate = $totalqty*$record['PurchaseDetails_Rate'];
                    $subtotal = $subtotal+$rate;
                ?>
                <tr>
                    <td><?php echo $record['Product_Name'] ?></td>
                    <td><?php echo $totalqty; ?></td>
                    <td><?php echo $record['PurchaseDetails_Rate']; ?></td>
                    <td><?php echo $rate ?></td>
                    <td><?php if($record['PurchaseDetails_Unit']==""){echo "pcs";} else{echo $record['PurchaseDetails_Unit']; }?></td>
                </tr>
        <?php } }}
        $sqld = mysql_query("SELECT tbl_purchaseinventory.*,tbl_product.*,tbl_purchasedetails.* FROM tbl_purchaseinventory left join tbl_product on tbl_product.Product_SlNo = tbl_purchaseinventory.purchProduct_IDNo left join tbl_purchasedetails on tbl_purchasedetails.Product_IDNo = tbl_product.Product_SlNo  group by tbl_purchaseinventory.PurchaseInventory_packname");
        while($record = mysql_fetch_array($sqld)){
            
                $totalqty = $record['PurchaseInventory_packqty'] -$record['PurchaseInventory_returnqty'];
                $totalqty = $totalqty-$record['PurchaseInventory_DamageQuantity'];
                
                $PID = $record['purchProduct_IDNo'];
                // Sell qty
                $sqqf = mysql_query("SELECT * FROM tbl_saleinventory WHERE sellProduct_IdNo = '$PID' group by SaleInventory_packname");
                $or = mysql_fetch_array($sqqf);
                
                if($or['SaleInventory_packname'] !=""){
                $sellTOTALqty = $or['SaleInventory_qty'];
                $sellTOTALqty = $sellTOTALqty-$or['SaleInventory_DamageQuantity'];
                $totalqty = $totalqty -$sellTOTALqty+$or['SaleInventory_returnqty'];
                if($totalqty !="0"){
                    $rate = $totalqty*$record['PackPice'];
                    $subtotal = $subtotal+$rate;
                ?>
                <tr>
                    <td><?php echo $or['SaleInventory_packname'] ?></td>
                    <td><?php echo $totalqty; ?></td>
                    <td><?php echo $record['PackPice']; ?></td>
                    <td><?php echo $rate ?></td>
                    <td><?php if($record['PurchaseDetails_Unit']==""){echo "pcs";} else{echo $record['PurchaseDetails_Unit']; }?></td>
                </tr>
        <?php } }}?>
                <tr>
                    <td style="border:0px"></td>
                    <td style="border:0px"></td>
                    <td><strong>Sub Total:</strong> </td>
                    <td><strong><?php echo $subtotal ?> Tk</strong></td>
                    <td style="border:0px"></td>
                </tr>
              </table>
            </td>
            <!-- Page Body end -->
       
    </table>
    </td>
  </tr>
  
</table>

<div class="provied">
  
  <span style="float:left;font-size:11px;">
<i>"THANK YOU FOR YOUR BUSINESS"</i><br>
  Software Provied By Link-Up Technology</span>
</div>
<div class="signature">
<span style="border-top:1px solid #000;">
  Authorize Signature
</span>
</div>
</body>
</html>

