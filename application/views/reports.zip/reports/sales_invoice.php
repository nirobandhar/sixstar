
<!DOCTYPE html>
<html>
<head>
<title> </title>
<meta charset='utf-8'>
    <link href="<?php echo base_url()?>css/prints.css" rel="stylesheet" />
    <link href="<?php echo base_url()?>assets/css/custom-styles.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/print.css">
</head>
<style type="text/css" media="print">
.hide{display:none}

</style>
<script type="text/javascript">
function printpage() {
document.getElementById('printButton').style.visibility="hidden";
window.print();
document.getElementById('printButton').style.visibility="visible";  
}
</script>
<body style="background:none;">
<input name="print" type="button" value="Print" id="printButton" onClick="printpage()">

      <table width="800px" >
        <tr>
          <td>
            <!-- <img src="<?php echo base_url();?>assets/img/logo.png" alt="Logo" style="margin-bottom:-50px"> -->
            <div class="headline">
            <div style="text-align:center" >
             <strong style="font-size:18px">M/S. KHAN TRADING COMPANY</strong><br>
             Chastia Electric Market, Shop no.13/A, 134/1 Nawabpur Road, Dhaka-1100<br>
             Phone: 7117527, 7173284 Mobile: 01711-708533, 01711-150254<br>
          
              </div>
          </div>
          </td>
        </tr>
        <tr>
          <td style="float:right">
            <table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="250px" style="text-align:right;"><strong></td>
              </tr>
          </table>
          </td>
        </tr>
        <tr>
            <td colspan="2"><hr><hr></td>
            <td colspan="2"><br></td>
        </tr>
        <tr>
            <td colspan="2" style="background:#ddd;" align="center"><h2 >Sales Invoice</h2></td>
        </tr>
        <tr>
            <td>
            <!-- Page Body -->
           <?php 
            $sql = mysql_query("SELECT tbl_salesmaster.*, tbl_salesmaster.AddBy as served, tbl_customer.* FROM tbl_salesmaster left join tbl_customer on tbl_customer.Customer_SlNo = tbl_salesmaster.SalseCustomer_IDNo where tbl_salesmaster.SaleMaster_SlNo = '$id'");
            $selse = mysql_fetch_array($sql);?>
              <table  cellspacing="0" cellpadding="0" width="100%">
                <tr>
                  <td>
                    <table width="100%">
                      <tr>
                          <td><strong>Customer ID </strong></td>
                          <td>:</td>
                          <td><?php echo $selse['Customer_Code']; ?></td>
                      </tr> 
                      <tr>
                          <td><strong>Customer Name </strong></td>
                          <td>:</td>
                          <td><?php echo $selse['Customer_Name']; ?></td>
                      </tr> 
                      <tr>
                          <td><strong>Customer Address </strong></td>
                          <td>:</td>
                          <td><?php echo $selse['Customer_Address']; ?></td>
                      </tr>
                      <tr>
                          <td><strong>Contact no </strong></td>
                          <td>:</td>
                          <td><?php echo $selse['Customer_Mobile']; ?></td>
                      </tr>              
                  </table>
                  </td>
                  <td>
                   <table width="100%">
                    <tr>
                        <td><strong>Invoice no </strong></td>
                        <td>:</td>
                        <td><?php echo $selse['SaleMaster_InvoiceNo']; ?></td>
                    </tr> 
                    <tr>
                        <td><strong>Sales Date </strong></td>
                        <td>:</td>
                        <td><?php echo $selse['SaleMaster_SaleDate']; ?></td>
                    </tr> 
                    <tr>
                        <td><strong>Served by </strong></td>
                        <td>:</td>
                        <td><?php echo $selse['served']; ?></td>
                    </tr> 
                </table>
                  </td>
                </tr>
              </table>
            </td>
            
            <!-- Page Body end -->
        </tr>
          <tr>
            <td colspan="2"><br></td>
        </tr>
        <tr>
          <td>
            <table class="border" cellspacing="0" cellpadding="0" width="100%">
                <tr>
                   <th align="center">SI No.</th>
                   <th>Product Information</th>
                   <th align="center">Quantity</th>
                   <th align="center">Rate</th>
                   <th>Amount</th>
                </tr>
                <?php $i = "";
        $totalamount = "";
        $packageName ="";
        $Ptotalamount = "";
        $ssql = mysql_query("SELECT tbl_saledetails.*, tbl_product.*  FROM tbl_saledetails left join tbl_product on tbl_product.Product_SlNo = tbl_saledetails.Product_IDNo where tbl_saledetails.SaleMaster_IDNo = '$id'");
        while($rows = mysql_fetch_array($ssql)){ 
           
            $packageName = $rows['packageName'];
            if($packageName==""){
            $amount = $rows['SaleDetails_Rate']*$rows['SaleDetails_TotalQuantity'] ;
            $totalamount = $totalamount+$amount;
            $i++;
        ?>
        <tr>
            <td align="center"><?php echo $i; ?></td>
            <td><?php echo $rows['Product_Name'] ?></td>
            <td align="center"><?php echo $rows['SaleDetails_TotalQuantity'] ?> <?php echo $rows['SaleDetails_unit'] ?></td>
            <td align="center"><?php echo $rows['SaleDetails_Rate'] ?></td>
            <td><?php echo $amount; ?></td>
        </tr>
        <?php } }
            $ssqls = mysql_query("SELECT tbl_saledetails.*, tbl_product.*  FROM tbl_saledetails left join tbl_product on tbl_product.Product_SlNo = tbl_saledetails.Product_IDNo where tbl_saledetails.SaleMaster_IDNo = '$id' group by tbl_saledetails.packageName");
            while($rows = mysql_fetch_array($ssqls)){ $i++;
                if($rows['packageName']!=""){
                $Pamount = $rows['packSellPrice']*$rows['SeleDetails_qty'] ;
                $Ptotalamount = $Ptotalamount+$Pamount;
            ?>
            <tr>
                <td align="center"><?php echo $i; ?></td>
                <td><?php echo $rows['packageName'] ?></td>
                <td align="center"><?php echo $rows['SeleDetails_qty'] ?> <?php echo $rows['SaleDetails_unit'] ?></td>
                <td align="center"><?php echo $rows['packSellPrice'] ?></td>
                <td><?php echo $Pamount; ?></td>
            </tr>
        <?php } }?>
        <tr>
            <td colspan="3" style="border:0px"></td>
            <td style="border:0px"><strong>Sub Total :</strong> </td>
            <td style="border:0px"><?php $totalamount =$totalamount+$Ptotalamount; echo number_format($totalamount,2); ?></td>
        </tr>
                <tr>
            <td  style="border:0px"><strong>Previous Due</strong></td>
            <td  style="border:0px;color:red;">
                <!-- Previous Due Customer -->
                <?php $cusotomerID = $selse['Customer_SlNo']; 
                    $Customerpaid='';
                    $Customerpurchase='';
                    $sql = mysql_query("SELECT * FROM tbl_customer_payment WHERE CPayment_customerID = '".$cusotomerID."'");
                    while($row = mysql_fetch_array($sql)){
                        $Customerpaid = $Customerpaid+$row['CPayment_amount'];    
                    }
                    $sqls = mysql_query("SELECT * FROM tbl_salesmaster WHERE SalseCustomer_IDNo = '".$cusotomerID."'");
                    while($rows = mysql_fetch_array($sqls)){
                        $Customerpurchase = $Customerpurchase +$rows['SaleMaster_SubTotalAmount']; 
                    }
                    $vat = $selse['SaleMaster_TaxAmount'];  $vat = ($totalamount*$vat)/100;
                    $all = $totalamount-$selse['SaleMaster_TotalDiscountAmount']+ $selse['SaleMaster_Freight']+$vat;  $CurrenDue = $all-$selse['SaleMaster_PaidAmount'];
                     $previousdue= $Customerpurchase-$Customerpaid;
                     $previousdue = $previousdue-$CurrenDue;
                    if($previousdue==''){echo'0';}echo $previousdue;
                ?>
                <!-- Previous Due Customer End -->
            </td>
            <td  style="border:0px"></td>
            <td style="border:0px"><strong>Vat :</strong> </td>
            <td style="border:0px"><?php echo $vat ?></td>
        </tr>
        <tr>
            <td style="border:0px"><strong>Current Due</strong></td>
            <td style="border:0px;color:red;"><?php if($CurrenDue==''){echo '0';} echo $CurrenDue ?></td>
            <td style="border:0px"></td>
            <td style="border:0px"><strong>Frieght :</strong> </td>
            <td style="border:0px"><?php $Frieght = $selse['SaleMaster_Freight']; echo number_format($Frieght,2) ?></td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #999;border-left: 0px ;border-right: 0px ;border-bottom: 0px ;"><strong>Totul Due</strong> </td>
            <td style="color:red;border-top: 1px solid #999;border-left: 0px ;border-right: 0px ;border-bottom: 0px ;"><?php if($previousdue+$CurrenDue==''){echo '0';} echo $previousdue+$CurrenDue; ?></td>
            <td style="border:0px"></td>
            <td style="border:0px"><strong>Discount :</strong> </td>
            <td style="border:0px"><?php $discount = $selse['SaleMaster_TotalDiscountAmount'];echo number_format($discount,2) ?></td>
        </tr>
                 <tr>
                    <td colspan="3" style="border:0px"></td>
                    <td colspan="2" style="border-top: 2px solid #999;border-left: 0px ;border-right: 0px ;border-bottom: 0px ;"></td>
                   
                </tr>
                <tr>
                    <td colspan="3" style="border:0px"></td>
                    <td style="border:0px"><strong>Total :</strong> </td>
                    <td style="border:0px"><strong><?php $grandtotal = $totalamount-$discount+ $Frieght+$vat; echo number_format($grandtotal,2)?></strong></td>
                </tr>
                <tr>
                    <td colspan="3" style="border:0px"></td>
                    <td style="border:0px"><strong>Paid :</strong> </td>
                    <td style="border:0px"><?php $paid = $selse['SaleMaster_PaidAmount']; echo number_format($paid,2);?></td>
                </tr>
                <tr>
                    <td colspan="3" style="border:0px"></td>
                    <td colspan="2" style="border-top: 2px solid #999;border-left: 0px ;border-right: 0px ;border-bottom: 0px ;"></td>
                   
                </tr>
                <tr>
                    <td colspan="3" style="border:0px"></td>
                    <td style="border:0px"><strong>Due :</strong> </td>
                    <td style="border:0px"><?php echo number_format($grandtotal-$paid,2); ?></td>
                </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td>
            <p><strong>Total (in word): </strong><?php 

function convertNumberToWord($num = false)
{
    $num = str_replace(array(',', ' '), '' , trim($num));
    if(! $num) {
        return false;
    }
    $num = (int) $num;
    $words = array();
    $list1 = array('', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven',
        'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'
    );
    $list2 = array('', 'ten', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety', 'hundred');
    $list3 = array('', 'thousand', 'million', 'billion', 'trillion', 'quadrillion', 'quintillion', 'sextillion', 'septillion',
        'octillion', 'nonillion', 'decillion', 'undecillion', 'duodecillion', 'tredecillion', 'quattuordecillion',
        'quindecillion', 'sexdecillion', 'septendecillion', 'octodecillion', 'novemdecillion', 'vigintillion'
    );
    $num_length = strlen($num);
    $levels = (int) (($num_length + 2) / 3);
    $max_length = $levels * 3;
    $num = substr('00' . $num, -$max_length);
    $num_levels = str_split($num, 3);
    for ($i = 0; $i < count($num_levels); $i++) {
        $levels--;
        $hundreds = (int) ($num_levels[$i] / 100);
        $hundreds = ($hundreds ? ' ' . $list1[$hundreds] . ' hundred' . ( $hundreds == 1 ? '' : 's' ) . ' ' : '');
        $tens = (int) ($num_levels[$i] % 100);
        $singles = '';
        if ( $tens < 20 ) {
            $tens = ($tens ? ' ' . $list1[$tens] . ' ' : '' );
        } else {
            $tens = (int)($tens / 10);
            $tens = ' ' . $list2[$tens] . ' ';
            $singles = (int) ($num_levels[$i] % 10);
            $singles = ' ' . $list1[$singles] . ' ';
        }
        $words[] = $hundreds . $tens . $singles . ( ( $levels && ( int ) ( $num_levels[$i] ) ) ? ' ' . $list3[$levels] . ' ' : '' );
    } //end for loop
    $commas = count($words);
    if ($commas > 1) {
        $commas = $commas - 1;
    }
    return implode(' ', $words);
}
if($paid==""|| $paid=="0"){
        echo "";
    }else{
        $inword = convertNumberToWord($paid)."Taka Only";
        echo strtoupper($inword);
    }
 ?></p><br>
    <h4>Notes: <?php echo $selse['SaleMaster_Description']; ?></h4>

          </td>
        </tr>
       
    </table></td>
  </tr>
  
</table>

<div class="provied">
  
  <span style="float:left;font-size:11px;">
<i>"THANK YOU FOR YOUR BUSINESS"</i><br>
  Software Provied By Link-Up Technology</span>
</div>
<div class="signature">
<span style="border-top:1px solid #000;">
  Authorize Signature
</span>
</div>
</body>
</html>

